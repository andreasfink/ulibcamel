Q.1228 Annex A
SDL Specification of the INAP CS-2

ETSI Secretariat
F-06921 Sophia Antipolis Cedex
France
Tel: +33 4 92 94 42 00    Fax: +33 4 93 65 47 16
secretariat@etsi.fr   http:\\www.etsi.fr


Copyright Notification
======================
No part may be reproduced except as authorized by written permission.
The copyright and the foregoing restriction extend to reproduction in
all media.



Note:
This SDL specificaiton forms the normative behaviour of the
INAP CS-2. An introduction to the modelling approach can be
found in Annex A, section 1 of Q.1228.

Version 1.0, January 6 1998.

Any further information may be obtained from:
  Jan Ellsberger
  ETSI PEX Group
  F-06921 Sophia Antipolis Cedex
  France
  Tel: +33 4 92 94 42 06  Fax: +33 4 93 65 38 51
  Jan.Ellsberger@etsi.fr or pex@etsi.fr


This SDL specification is best viewed with the font settings
Arial 8 for Headings and Arial 6 for symbol texts.